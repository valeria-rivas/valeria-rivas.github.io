//defining variables 
let x;
let y;
let vX = 200;
let vY = 200;

//settings of the page, the color of the flower
function setup() {
  createCanvas(400, 400);
  background(220);
  x = width/2;
  y = height/2;
  noStroke();
  //color of the flower fill
  fill(200,150,300,80);
  //text set up
  textSize(50);
  textStyle(ITALIC);
  text('Click on the', 20, 60);
  text('beautiful flower', 8, 100);
}
//begin to draw flower shape
function draw() {
  //set the center point
  translate (vX,vY);
  noStroke();
  //description for the flower to be drawn 
  for (let i = 0; i < 10; i++) {
  ellipse (6,15,20,70);
  rotate (PI/5); 
  }
}
function mousePressed(){
  //background changes color everytime mouse is clicked
  background (random(255),random(255),random(255));
  // call the variable for flower to move randomly
  vX = random(0, width);
  vY = random(0, height);
}
